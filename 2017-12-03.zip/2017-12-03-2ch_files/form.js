function postFormSuccess(response, statusText, xhr, $form) {
	if(typeof response !== 'object') {
		alert('Ошибка при парсинге ответа сервера!');
		return;
	}

	if(response.hasOwnProperty('message')) {
		alert(response.message);
		get_captcha();
		return;
	}

	$('#postform')[0].reset();
	get_captcha();
	updateThread();
}

function postFormError(xhr, status, error) {
	alert('Возникла ошибка при отправке поста!');
}

function postFormSubmit() {
	var input = $("<input>").attr("type", "hidden").attr("name", "json").val("1");
	$('#postform').append($(input));
	$('#postform').ajaxSubmit({
		success: postFormSuccess,
		error: postFormError
	});
}
