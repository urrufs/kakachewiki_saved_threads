﻿var refArr = [];
var doc = document;
var postByNum = [];
var ajaxPosts = {};
var refArr = [];
var style_cookie = "wakabastyle";

function get_cookie(name)
{
  var matches = document.cookie.match(new RegExp(
    "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
  ));
  return matches ? decodeURIComponent(matches[1]) : undefined;
};

function set_cookie(name,value,days)
{
	if(days)
	{
		var date=new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires="; expires="+date.toGMTString();
	}
	else expires="";
	document.cookie=name+"="+value+expires+"; path=/";
}

function get_password(name)
{
	var pass=get_cookie(name);
	if(pass) return pass;

	var chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	var pass='';

	for(var i=0;i<8;i++)
	{
		var rnd=Math.floor(Math.random()*chars.length);
		pass+=chars.substring(rnd,rnd+1);
	}

	return(pass);
}

function $id(id)
{return document.getElementById(id);}
function $n(id)
{return document.getElementsByName(id)[0];}
function $t(id,root)
{return(root||document).getElementsByTagName(id);}
function $c(id,root)
{return(root||document).getElementsByClassName(id);}
function $each(arr,fn)
{for(var el,i=0;el=arr[i++];)
fn(el);}
function $html(el,htm)
{var cln=el.cloneNode(false);cln.innerHTML=htm;el.parentNode.replaceChild(cln,el);return cln;}
function $attr(el,attr)
{for(var key in attr)
{if(key=='text')
{el.textContent=attr[key];continue;}
if(key=='value')
{el.value=attr[key];continue;}
if(key=='html')
{el.innerHTML=attr[key];continue;}
el.setAttribute(key,attr[key]);}
return el;}
function $event(el,events)
{for(var key in events){if(!events.hasOwnProperty(key))continue;if(el.addEventListener){el.addEventListener(key,events[key],false);}else{el.attachEvent(key,events[key]);}}}
function $before(el,nodes)
{for(var i=0,len=nodes.length;i<len;i++)
if(nodes[i])el.parentNode.insertBefore(nodes[i],el);}
function $after(el,nodes)
{var i=nodes.length;while(i--)if(nodes[i])el.parentNode.insertBefore(nodes[i],el.nextSibling);}
function $new(tag,attr,events)
{var el=document.createElement(tag);if(attr)$attr(el,attr);if(events)$event(el,events);return el;}
function $disp(el)
{el.style.display=el.style.display=='none'?'':'none';}
function $del(el)
{if(!el)return;if(el.parentNode)el.parentNode.removeChild(el);}
function $offset(el,xy)
{var c=0;while(el)
{c+=el[xy];el=el.offsetParent;}
return c;}
function $close(el)
{if(!el)return;var h=el.clientHeight- 18;el.style.height=h+'px';var i=8;var closing=setInterval(function()
{if(!el||i--<0)
{clearInterval(closing);$del(el);return;}
var s=el.style;s.opacity=i/10;s.paddingTop=parseInt(s.paddingTop)- 1+'px';s.paddingBottom=parseInt(s.paddingBottom)- 1+'px';var hh=parseInt(s.height)- h/10;s.height=(hh<0?0:hh)+'px';},35);}
function $show(el)
{var i=0;var showing=setInterval(function()
{if(!el||i++>8)
{clearInterval(showing);return;}
var s=el.style;s.opacity=i/10;s.paddingTop=parseInt(s.paddingTop)+ 1+'px';s.paddingBottom=parseInt(s.paddingBottom)+ 1+'px';},35);}

function insert(text)
{
	var textarea=document.forms.postform.shampoo;
	if(textarea)
	{
		if(textarea.createTextRange && textarea.caretPos) // IE
		{
			var caretPos=textarea.caretPos;
			caretPos.text=caretPos.text.charAt(caretPos.text.length-1)==" "?text+" ":text;
		}
		else if(textarea.setSelectionRange) // Firefox
		{
			var start=textarea.selectionStart;
			var end=textarea.selectionEnd;
			textarea.value=textarea.value.substr(0,start)+text+textarea.value.substr(end);
			textarea.setSelectionRange(start+text.length,start+text.length);
		}
		else
		{
			textarea.value+=text+" ";
		}
		textarea.focus();
	}
}

function highlight(post)
{
	var cells=document.getElementsByTagName("td");
	for(var i=0;i<cells.length;i++) if(cells[i].className=="highlight") cells[i].className="reply";

	var reply=document.getElementById(post);
	if(reply)
	{
		reply.className="highlight";
/*		var match=/^([^#]*)/.exec(document.location.toString());
		document.location=match[1]+"#"+post;*/
		return false;
	}

	return true;
}



function set_stylesheet(styletitle,norefresh)
{
	set_cookie("wakabastyle",styletitle,365);

	var links=document.getElementsByTagName("link");
	var found=false;
	for(var i=0;i<links.length;i++)
	{
		var rel=links[i].getAttribute("rel");
		var title=links[i].getAttribute("title");
		if(rel.indexOf("style")!=-1&&title)
		{
			links[i].disabled=true; // IE needs this to work. IE needs to die.
			if(styletitle==title) { links[i].disabled=false; found=true; }
		}
	}
	if(!found) set_preferred_stylesheet();
}

function set_preferred_stylesheet()
{
	var links=document.getElementsByTagName("link");
	for(var i=0;i<links.length;i++)
	{
		var rel=links[i].getAttribute("rel");
		var title=links[i].getAttribute("title");
		if(rel.indexOf("style")!=-1&&title) links[i].disabled=(rel.indexOf("alt")!=-1);
	}
}

function get_active_stylesheet()
{
	var links=document.getElementsByTagName("link");
	for(var i=0;i<links.length;i++)
	{
		var rel=links[i].getAttribute("rel");
		var title=links[i].getAttribute("title");
		if(rel.indexOf("style")!=-1&&title&&!links[i].disabled) return title;
	}
	return null;
}

function get_preferred_stylesheet()
{
	var links=document.getElementsByTagName("link");
	for(var i=0;i<links.length;i++)
	{
		var rel=links[i].getAttribute("rel");
		var title=links[i].getAttribute("title");
		if(rel.indexOf("style")!=-1&&rel.indexOf("alt")==-1&&title) return title;
	}
	return null;
}

function set_inputs(id) {
	var form = document.getElementById(id);
	var gb2 = form.gb2;
	var gb2val = get_cookie("gb2");

	if (gb2 && gb2val)
		for (var i = 0; i < gb2.length; i++) {
			gb2[i].checked = (gb2[i].value == gb2val);
		}
		
	with(form) {
		//if(!akane.value) akane.value=get_cookie("name"); 
		//if(!nabiki.value) nabiki.value=get_cookie("email"); 
		if(!password.value) password.value=get_password("password");
		shampoo.focus();
	}

	
	
}

function set_delpass(id) { 
	with(document.getElementById(id)) password.value=get_cookie("password");
}

function changeLayout(e)
{
	if(e.which<1040||e.which>1279)
        return;
    e.preventDefault();
    var key;
    switch(e.which)
    {
        case 1081:
            key='q';
            break;
        case 1094:
            key='w';
            break;
        case 1091:
            key='e';
            break;
        case 1082:
            key='r';
            break;
        case 1077:
            key='t';
            break;
        case 1085:
            key='y';
            break;
        case 1075:
            key='u';
            break;
        case 1096:
            key='i';
            break;
        case 1097:
            key='o';
            break;
        case 1079:
            key='p';
            break;
        case 1092:
            key='a';
            break;
        case 1099:
            key='s';
            break;
        case 1074:
            key='d';
            break;
        case 1072:
            key='f';
            break;
        case 1087:
            key='g';
            break;
        case 1088:
            key='h';
            break;
        case 1086:
            key='j';
            break;
        case 1083:
            key='k';
            break;
        case 1076:
            key='l';
            break;
        case 1103:
            key='z';
            break;
        case 1095:
            key='x';
            break;
        case 1089:
            key='c';
            break;
        case 1084:
            key='v';
            break;
        case 1080:
            key='b';
            break;
        case 1090:
            key='n';
            break;
        case 1100:
            key='m';
            break;
        default:
            return;
    }
    e.target.value=e.target.value+key;
}

function showVideo(videoid, pic)
{
	document.getElementById(videoid).style = 'display: block';
	document.getElementById(pic).style = 'display: none';
}

function get_captcha() {
	$.getJSON('/cgi/captcha', { task: 'get_id', json: '1' })
	.done(function(data) { 
		$('#imgcaptcha').prop('src', '/cgi/captcha?task=get_image&id='+data['id']);
		$('#captchaid').val(data['id']);
	})
	.fail(function() {
		
	});
}

$(document).ready(function() {
	get_captcha();
	setInterval(function() {
		get_captcha();
		}, 6000000);
});

function updateThread()
{
	var btn = document.getElementById('updatelink');
	btn.innerHTML='<img src="/css/images/loading.gif" style=\"vertical-align: middle;\"> Загрузка...';
	var mb = document.createElement('div');
	mb.id = "messagebox";
	mb.innerHTML = "<img style=\"vertical-align: middle;\" src=\"/css/images/loading.gif\" style=\"display:inline-block\"> <span style=\"vertical-align: middle;\"> Загрузка...</span>"
	mb.style = "overflow: hidden; background-color: #dddddd; border: 1px solid #333333; border-radius: 3px; position: fixed; top: 20px; right: 20px; display: none; padding: 3px;";
	document.body.appendChild(mb);
	$(mb).slideDown(200);
	var Thread = document.getElementsByClassName('thread')[0];
	var tNum = Thread.id.match(/\d+/)[0];
	var last = document.getElementsByClassName('post').length + 1;
	var board = window.location.pathname.split('/')[1];
	$.get('/' + board + '/res/' + tNum + '.json')
	.done(function(page)
	{
		var thread = page.threads[0];
		var posts = thread.posts;
		var newposts = posts.slice(last);
		for(var i = 0; i < newposts.length; i++)
		{
			var ppost = newposts[i];
			var newel = document.createElement('table');
			newel.id = 'post_' + ppost.num;
			newel.className = 'post';
			var innerHTML = "<tbody><tr><td class=\"doubledash\">&gt;&gt;</td><td class=\"reply new\" id=\"";
			innerHTML += ppost.num + '"><a name="' + ppost.num + '"></a><label><input type="checkbox" name="delete"  class="turnmeoff" value="' + ppost.num + '" />';
			if(ppost.subject != '')
			{
				innerHTML += '<span class="filetitle">' + ppost.subject + '</span>';
			}
			if(ppost.email != '')
			{
				innerHTML += '<a href="' + ppost.email + '"><TMPL_var name><span class="postertrip">' + ppost.trip + '</span></a>';
			}
			else 
			{
				innerHTML += ' ' + ppost.name + ' <span class="postertrip">' + ppost.trip + '</span>';
			}
			innerHTML += '</span><span class="posttime">' + ppost.date + '&nbsp;</span> </label><span class="reflink"> <a href="/' + board + '/res/' + ppost.parent + '.html#' + ppost.num + 
			'">№</a><a href="/' + board + '/res/' + ppost.parent + '.html#i' + ppost.num + '" onclick="javascript:insert(\'&gt;&gt;' + ppost.num + ')">' + ppost.num + ' </a></span>' +
			'&nbsp;  <br />';
			if(ppost.file_name != undefined)
			{
				innerHTML += '<span class="filesize"><a target="_blank" href="' + ppost.file_path + '">' + ppost.file_name + '</a>&nbsp;(<em>' + 				ppost.file_size + 'Кб, ' + ppost.file_width + 'x' + ppost.file_height + '</em>)&nbsp;</span><span class="thumbnailmsg">Показана уменьшенная копия, оригинал по клику.</span><br class="turnmeoff" /><a href="' 
				+ ppost.file_path + '" name="expandfunc" onClick="expand(' + ppost.num + ',\'' + ppost.file_path + '\',\'' + ppost.thumbnail + '\',' + ppost.file_width + ',' + ppost.file_height + ',' + ppost.tn_width + ',' + ppost.tn_height + '>); return false;"><img src="' + ppost.thumbnail + '" width="' + ppost.tn_width + '" height="' + ppost.tn_height + '" alt="' + 
				ppost.file_size + '" class="thumb" /></a>';
			}
			else if(ppost.video != undefined)
			{
				innerHTML += '<div style="float: left; margin: 5px; margin-right:10px">' + ppost.video + '</div>';
			}
			innerHTML += '<blockquote id="m' + ppost.num + '" class="postMessage">' + ppost.comment + '</blockquote></td></tr></tbody>';
			newel.innerHTML = innerHTML;
			document.getElementById('thread_' + ppost.parent).appendChild(newel);
		}
		$each($X('.//td[@class="reply"]'), function(post) { postByNum[post.id.match(/\d+/)] = post; });
		while(Thread.getElementsByTagName('small').length > 0)
		{
			Thread.getElementsByTagName('small')[0].parentNode.removeChild(Thread.getElementsByTagName('small')[0]);
		}
		doRefPreview();
		doRefMap();
		setTimeout(function() {
			document.getElementById('updatelink').innerHTML = '[<a style="cursor: pointer;" onclick="javascript:updateThread(); return false;">Обновить тред</a>]';
			$('#messagebox').slideUp(200);
			document.body.removeChild(document.getElementById('messagebox'));
			}, 1000);
		setTimeout(function() {
				while(document.getElementsByClassName('reply new').length > 0)
				{
					document.getElementsByClassName('reply new')[0].className = 'reply';
				}
			}, 5000);
	});
}
function $X(path, root) {
    return doc.evaluate(path, root || doc, null, 6, null);
}
function $x(path, root) {
    return doc.evaluate(path, root || doc, null, 8, null).singleNodeValue;
}
function $del(el) {
    if(el) el.parentNode.removeChild(el);
}
function $each(list, fn) {
    if(!list) return;
    var i = list.snapshotLength;
    if(i > 0) while(i--) fn(list.snapshotItem(i), i);
}

function delPostPreview(e) {
    var el = $x('ancestor-or-self::*[starts-with(@id,"pstprev")]', e.relatedTarget);
	if(!el) $each($X('.//div[starts-with(@id,"pstprev")]'), function(clone) { $del(clone); });
	else while(el.nextSibling) $del(el.nextSibling);
}

function showPostPreview(e) {
    var tNum = this.pathname.substring(this.pathname.lastIndexOf('/')).match(/\d+/);
    var pNum = this.hash.match(/\d+/) || tNum;
    var brd = this.pathname.match(/[^\/]+/);
    var x = e.clientX + (doc.documentElement.scrollLeft || doc.body.scrollLeft) - doc.documentElement.clientLeft + 1;
    var y = e.clientY + (doc.documentElement.scrollTop || doc.body.scrollTop) - doc.documentElement.clientTop;
    var cln = doc.createElement('div');
    cln.id = 'pstprev_' + pNum;
    cln.className = 'reply';
    cln.style.cssText = 'position:absolute; z-index:950; border:solid 1px #BBBBBB; top:' + y + 'px;' +
        (x < doc.body.clientWidth/2 ? 'left:' + x + 'px' : 'right:' + parseInt(doc.body.clientWidth - x + 1) + 'px');
    cln.addEventListener('mouseout', delPostPreview, false);
    var aj = ajaxPosts[tNum];
    var functor = function(cln, html) {
        cln.innerHTML = html;
        doRefPreview(cln);
        if(!$x('.//small', cln) && ajaxPosts[tNum] && ajaxPosts[tNum][pNum] && refArr[pNum])
            showRefMap(cln, pNum, tNum, brd);
    };
    cln.innerHTML = 'Загрузка';
    if(postByNum[pNum]) functor(cln, postByNum[pNum].innerHTML);
    else { if(aj && aj[pNum]) functor(cln, aj[pNum]);
           else AJAX(brd, tNum, function(err) { functor(cln, err || ajaxPosts[tNum][pNum] || 'Пост не найден'); });
         };
    $del(doc.getElementById(cln.id));
    $x('.//form[@id="delform"]').appendChild(cln);
}

function doRefPreview(node) {
    $each($X('.//a[starts-with(text(),">>")]', node || doc), function(link) {
        link.addEventListener('mouseover', showPostPreview, false);
        link.addEventListener('mouseout', delPostPreview, false);
    });
}

function waitDelPostPreview(e) {
	setTimeout(function() {
		delPostPreview(e);
	}, 2000);
}

function getRefMap(post, pNum, rNum) {
    if(!refArr[rNum]) refArr[rNum] = pNum;
    else if(refArr[rNum].indexOf(pNum) == -1 && refArr[rNum][0].indexOf(pNum)) refArr[rNum] = pNum + ', ' + refArr[rNum];
}

function showRefMap(post, pNum, tNum, brd) {
    var ref = refArr[pNum].toString().replace(/(\d+)/g, 
    '<a href="' + (tNum ? '/' + brd + '/res/' + tNum + '.html#$1' : '#$1') + '" onclick="highlight($1)">&gt;&gt;$1</a>');
    var map = doc.createElement('small');
    map.id = 'rfmap_' + pNum;
    map.innerHTML = '<br><i class="abbrev">Ответы: ' + ref + '</i><br>';
    doRefPreview(map);
    if(post && post.innerHTML.indexOf('<i class="abbrev">') == -1) post.appendChild(map);
    else {
        var el = $x('.//a[@name="' + pNum + '"]');
        while(el.tagName != 'BLOCKQUOTE') el = el.nextSibling;
        el.parentNode.insertBefore(map, el.nextSibling);
    }
}

function doRefMap() {
    $each($X('.//a[starts-with(text(),">>")]'), function(link) {
        if(!/\//.test(link.textContent)) {
            var rNum = link.hash.match(/\d+/);
            var post = $x('./ancestor::td', link);
            if((postByNum[rNum] || $x('.//a[@name="' + rNum + '"]')) && post)
                getRefMap(post, post.id.match(/\d+/), rNum);
        }
    });
    for(var rNum in refArr)
        showRefMap(postByNum[rNum], rNum);
}

function set_cookie(name,value,days) {
    if(days)
    {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        var expires = "; expires=" + date.toGMTString();
    }
    else expires = "";
    document.cookie = name + "=" + value + expires + "; path=/";
}

function get_password(name) {
    var pass=get_cookie(name);
    if(pass) return pass;

    var chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    pass = '';

    for(var i = 0; i < 12; i++)
    {
        var rnd=Math.floor(Math.random()*chars.length);
        pass+=chars.substring(rnd,rnd+1);
    }

    return(pass);
}

function update_captcha(e) {
    e.src = e.src.replace(/dummy=[0-9]*/, "dummy=" + Math.floor(Math.random() * 1000).toString());
}

function update_captcha2() {
    var e = document.getElementById('imgcaptcha');
    if (e) update_captcha(e);
}

function insert(text) {
    var textarea = document.forms.postform.shampoo;
    if(textarea)
    {
        if(textarea.createTextRange && textarea.caretPos) // IE
        {
            var caretPos = textarea.caretPos;
            caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == " " ? text + " " : text;
        }
        else if(textarea.setSelectionRange) // Firefox
        {
            var start = textarea.selectionStart;
            var end = textarea.selectionEnd;
            textarea.value=textarea.value.substr(0, start) + text + textarea.value.substr(end);
            textarea.setSelectionRange(start+text.length, start+text.length);
        }
        else
        {
            textarea.value += text + " ";
        }
        textarea.focus();
    }
}

function highlight(post) {
    var cells=document.getElementsByTagName("td");
    for(var i = 0; i < cells.length; i++)
        if(cells[i].className == "highlight")
            cells[i].className = "reply";

    var reply = document.getElementById("reply" + post);
    if(reply)
    {
        reply.className = "highlight";
        /*      var match=/^([^#]*)/.exec(document.location.toString());
                document.location=match[1]+"#"+post;*/
        return false;
    }

    return true;
}

/** **/


function set_stylesheet_frame(styletitle,framename)
{
	set_stylesheet(styletitle);
	var list = get_frame_by_name(framename);
	if(list) set_stylesheet(styletitle,list);
}

function set_stylesheet(styletitle,target)
{
	set_cookie("wakabastyle",styletitle,365);

	var links = target ? target.document.getElementsByTagName("link") : document.getElementsByTagName("link");
	var found=false;
	for(var i=0;i<links.length;i++)
	{
		var rel=links[i].getAttribute("rel");
		var title=links[i].getAttribute("title");
		if(rel.indexOf("style")!=-1&&title)
		{
			links[i].disabled=true; // IE needs this to work. IE needs to die.
			if(styletitle==title) { links[i].disabled=false; found=true; }
		}
	}
	if(!found)
	{
		if(target) set_preferred_stylesheet(target);
		else set_preferred_stylesheet();
	}
}

function set_preferred_stylesheet(target)
{
	var links = target ? target.document.getElementsByTagName("link") : document.getElementsByTagName("link");
	for(var i=0;i<links.length;i++)
	{
		var rel=links[i].getAttribute("rel");
		var title=links[i].getAttribute("title");
		if(rel.indexOf("style")!=-1&&title) links[i].disabled=(rel.indexOf("alt")!=-1);
	}
}

function get_active_stylesheet()
{
	var links=document.getElementsByTagName("link");
	for(var i=0;i<links.length;i++)
	{
		var rel=links[i].getAttribute("rel");
		var title=links[i].getAttribute("title");
		if(rel.indexOf("style")!=-1&&title&&!links[i].disabled) return title;
	}
	return null;
}

function get_preferred_stylesheet()
{
	var links=document.getElementsByTagName("link");
	for(var i=0;i<links.length;i++)
	{
		var rel=links[i].getAttribute("rel");
		var title=links[i].getAttribute("title");
		if(rel.indexOf("style")!=-1&&rel.indexOf("alt")==-1&&title) return title;
	}
	return null;
}


/** **/

function get_frame_by_name(name) {
    var frames = window.parent.frames;
    for(var i = 0; i < frames.length; i++)
    {
        if(name == frames[i].name) { return(frames[i]); }
    }
}

function lazyadmin() {
    var admin=get_cookie("wakaadmin");
    if(!admin){
        return;
    }
    var posts = document.getElementsByClassName('reflink');
    var post;
    var id;
    var pos;
    var tmp;
    var board=document.location.toString().split("/")[3];
    for(var i=0;i<posts.length;i++){
        post = posts[i];
        //This is wrong, but monkey cannot Regexp.
        pos=post.innerHTML.indexOf('в„–');
        //alert(post.innerHTML+"\n"+pos);
        if(pos>0)
        {
            tmp=post.innerHTML.substring(pos+1);
            id=tmp.substring(0,tmp.indexOf('<'));
            post.innerHTML+="[ <a title=\"Удалить это сообщение\" href=\"/"+board+"/wakaba.pl?task=delete&admin="+admin+"&delete="+id+"&mode=2\">D</a> | ";
            post.innerHTML+="<a title=\"Забанить автора\" href=\"/"+board+"/wakaba.pl?admin="+admin+"&task=banpost&post="+id+"&mode=3\" onclick=\"return do_ban(this)\">B</a> | ";
            post.innerHTML+="<a title=\"Забанить автора и удалить это сообщение\" href=\"/"+board+"/wakaba.pl?admin="+admin+"&task=banpost&post="+id+"&mode=1\" onclick=\"return do_ban(this)\">D&B</a> | ";
            post.innerHTML+="<a title=\"Удалить все сообщения этого автора\" href=\"/"+board+"/wakaba.pl?task=banpost&admin="+admin+"&post="+id+"&mode=5\">DAll</a> | ";
            post.innerHTML+="<a title=\"Забанить автора и удалить все его сообщения\" href=\"/"+board+"/wakaba.pl?admin="+admin+"&task=banpost&post="+id+"&mode=6\" onclick=\"return do_ban(this)\">DAll&B</a> | ";
            post.innerHTML+="<a title=\"Удалить файл из сообщения\" href=\"/"+board+"/wakaba.pl?task=delete&admin="+admin+"&delete="+id+"&fileonly=on&mode=2\">F</a> | ";
            post.innerHTML+="<a title=\"Перенести в архив\" href=\"/"+board+"/wakaba.pl?task=delete&admin="+admin+"&archive=Archive&mode=2&delete="+id+"\">A</a> ]";
            
        }

    }
}


function set_inputs(id) {
    var form = document.getElementById(id);
    with(document.getElementById(id)) 
    {
        //if(!field2.value) field2.value=get_cookie("email"); 
        if(!password.value) password.value=get_password("password");
        var gb2 = form.gb2; var gb2val = get_cookie("gb2"); 
        if (gb2 && gb2val) for (var i = 0; i < gb2.length; i++) 
        {
            gb2[i].checked = (gb2[i].value == gb2val);
        }
    }
} 

function set_delpass(id) { 
    with(document.getElementById(id))
        password.value=get_cookie("password"); 
}

function buttonOK() {
    var select  = document.getElementById("path");
    var option = document.getElementById("opt"+select.selectedIndex);
    var input = document.getElementById("dynamicNamed");      
    input.name = option.value;
}

//function set_delpass(id)
//{
//  with(document.getElementById(id)) password.value=get_cookie("password");
//}

function do_ban(el) {
    var reason=prompt("Give a reason for this ban:");
    if(reason) document.location=el.href+"&comment="+encodeURIComponent(reason);
    return false;
}

function load_style() {
    if(style_cookie)
    {
        var cookie=get_cookie(style_cookie);
        var title=cookie?cookie:get_preferred_stylesheet();
        set_stylesheet(title);
    }
}

function set_global_style() {
    if(style_cookie)
    {
        var cookie = get_cookie(style_cookie);
        var title = cookie?cookie:get_preferred_stylesheet();
        var frames = window.parent.frames;
        for (var i = 0; i < frames.length; i++) {
            set_stylesheet(title, frames[i]);
        }
    }
}

function update_captcha() {
    var e = document.getElementById('imgcaptcha');
    if (e) {
        e.src = e.src.replace(/dummy=[0-9]*/, "dummy=" + Math.floor(Math.random() * 1000).toString());
    }
}

function expand(num,src,thumb_src,n_w,n_h,o_w,o_h) {
    var mode=n_w>o_w&&n_h>o_h;
    var ext=src.split('.')[1];
    var el = document.getElementById("th" + num);
    var img = el.getElementsByTagName('img')[0];
    if(n_w==o_w&&n_h==o_h&&ext=="gif"&&img.src.search("thumb")>0)
    {
        mode=true;
    }

    if(n_w>screen.width)
    {
        n_h=((screen.width-80)*n_h)/n_w;
        n_w=screen.width-80;
    }
	el.setAttribute('onclick', "expand('"+num+"','"+src+"','"+thumb_src+"',"+o_w+","+o_h+","+n_w+","+n_h+"); return false;");
    el.innerHTML="<img src=\""+(mode ? src : thumb_src)+"\" width=\""+n_w+"\" height=\""+n_h+"\" class=\""+(mode ? 'image' : 'thumb')+"\" />";
}

function AJAX(b, id, fn) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if(xhr.readyState != 4) return;
        if(xhr.status == 200) {
            var x = xhr.responseText;
            var threads = x.substring(x.search(/<form[^>]+del/) + x.match(/<form[^>]+del[^>]+>/).toString().length, x.indexOf('userdelete">') - 13).split(/<br style="clear:left"[\s\/>]*<h[r\s\/]*>/i);
            for(var i = 0; i < threads.length; i++) {
                var tNum = threads[i].match(/<input[^>]+checkbox[^>]+>/i)[0].match(/(?:")(\d+)(?:")/)[1];
                var posts = threads[i].split(/<table[^>]*>/);
                ajaxPosts[tNum] = {keys: []};
                for(var j = 0, pLen = posts.length; j < pLen; j++) {
                    var x = posts[j];
                    var pNum = x.match(/<input[^>]+checkbox[^>]+>/i)[0].match(/(?:")(\d+)(?:")/)[1];
                    ajaxPosts[tNum].keys.push(pNum);
                    ajaxPosts[tNum][pNum] = x.substring((!/<\/td/.test(x) && /filesize">/.test(x)) ? x.indexOf('filesize">') - 13 : x.indexOf('<label'), /<\/td/.test(x) ? x.lastIndexOf('</td') : (/omittedposts">/.test(x) ? x.lastIndexOf('</span') + 7 : x.lastIndexOf('</blockquote') + 13));
                    x = ajaxPosts[tNum][pNum].substr(ajaxPosts[tNum][pNum].indexOf('<blockquote>') + 12).match(/&gt;&gt;\d+/g);
                    if(x) for(var r = 0; rLen = x.length, r < rLen; r++)
                        getRefMap(x[r], pNum, x[r].replace(/&gt;&gt;/g, ''));
                }
            }
            fn();
        } else fn('HTTP ' + xhr.status + ' ' + xhr.statusText);
    };
    xhr.open('GET', '/' + b + '/res/' + id + '.html', true);
    xhr.send(false);
}

function makeQuickReplies()
{
	if(window.location.href.indexOf('/res/') != -1)
	{
		var replies = document.getElementsByClassName('reply');
		for(var i = 0; i < replies.length; i++)
		{
			if(document.getElementById('de-qarea') == undefined) {
				var replynum = replies[i].id;
				var qrbtn = document.createElement('a');
				qrbtn.className = 'qreply_btn';
				qrbtn.href = '#';
				qrbtn.id = "btn_" + replynum;
				qrbtn.setAttribute('onclick', 'quickReply(' + replynum + '); return false;');
				document.getElementById('reflink_' + replynum).appendChild(qrbtn);
			}
		}
		var opnum = document.getElementsByClassName('thread')[0].id.replace('thread_', '');
		var qrbtn = document.createElement('a');
		qrbtn.className = 'qreply_btn';
		qrbtn.href = '#';
		qrbtn.id = "btn_" + opnum;
		qrbtn.setAttribute('onclick', 'quickReply(' + opnum + '); return false;');
		document.getElementById('reflink_' + opnum).appendChild(qrbtn);
	}
}

function quickReply(replynum)
{
	if(document.getElementById('replyarea_' + replynum) == undefined)
	{
		var form = document.getElementById('postform').cloneNode();
		form.innerHTML = document.getElementById('postform').innerHTML;
		if(document.getElementsByClassName('quickreply').length > 0) { document.getElementsByClassName('quickreply')[0].parentNode.removeChild(document.getElementsByClassName('quickreply')[0]); }
		if(document.getElementsByClassName('postarea').length > 0) {
			if(get_cookie('formopen') == 'top')
			{
				var openform = document.createElement('div');
				openform.className = 'hiddenpostarea';
				openform.id = 'hiddenpostareatop';
				openform.innerHTML = '<br><hr>[ <a onclick="openForm(\'top\'); return false;" class="unhidereplyform" href="#">Раскрыть форму</a> ]<br><hr>';
				var topform = document.getElementsByClassName('postarea')[0];
				topform.parentNode.insertBefore(openform, topform);
				topform.parentNode.removeChild(topform);
			}
			else
			{
				var openform = document.createElement('div');
				openform.className = 'hiddenpostarea';
				openform.id = 'hiddenpostareabottom';
				openform.innerHTML = '<br><hr>[ <a onclick="openForm(\'bottom\'); return false;" class="unhidereplyform" href="#">Раскрыть форму</a> ]<br><hr>';
				var bottomform = document.getElementsByClassName('postarea')[0];
				bottomform.parentNode.insertBefore(openform, bottomform);
				bottomform.parentNode.removeChild(bottomform);
			}
		}
		var replyarea = document.createElement('div');
		replyarea.id = 'replyarea_' + replynum;
		replyarea.className = 'reply quickreply';
		replyarea.appendChild(form);
		document.getElementById('post_' + replynum).parentNode.insertBefore(replyarea, document.getElementById('post_' + replynum).nextSibling);
		insert('>>' + replynum);
	}
	else
	{
		openForm(get_cookie('formopen'));
	}
	return false;
}

function openForm(which)
{
	if(which == 'top')
	{
		if(document.getElementsByClassName('reply quickreply').length > 0)
		{
			var qform = document.getElementsByClassName('reply quickreply')[0].getElementsByTagName('form')[0];
		}
		else
		{
			var qform = document.getElementById('postform');
		}
		var postarea = document.getElementById('hiddenpostareatop');
		var postform = qform.cloneNode();
		postform.innerHTML = qform.innerHTML;
		postform.onsubmit = null;
		var openform = document.createElement('div');
		openform.className = 'hiddenpostarea';
		openform.id = 'hiddenpostareabottom';
		openform.innerHTML = '<br><hr>[ <a onclick="openForm(\'bottom\'); return false;" class="unhidereplyform" href="#">Раскрыть форму</a> ]<br><hr>';
		var bottomform = document.getElementsByClassName('postarea')[0];
		if(bottomform){
			bottomform.parentNode.insertBefore(openform, bottomform);
			bottomform.parentNode.removeChild(bottomform);
		}
		postarea.className = 'postarea';
		postarea.innerHTML = '';
		if(document.getElementsByClassName('reply quickreply').length > 0) { document.getElementsByClassName('reply quickreply')[0].parentNode.removeChild(document.getElementsByClassName('reply quickreply')[0]); }
		/* var back = document.createElement('div');
		back.className = 'backdiv';
		back.style = 'font-size:0.9em; text-align: left;';
		back.innerHTML = '[<a href="/b/">Назад</a>]';
		postarea.appendChild(back);
		var threader = document.createElement('div');
		threader.className = 'theader';
		threader.innerHTML = 'Ответ';
		postarea.appendChild(threader); */
		postarea.appendChild(postform);
		set_cookie('formopen', 'top');

	}
	else if(which == 'bottom')
	{
		if(document.getElementsByClassName('reply quickreply').length > 0)
		{
			var qform = document.getElementsByClassName('reply quickreply')[0].getElementsByTagName('form')[0];
		}
		else
		{
			var qform = document.getElementById('postform');
		}
		var postarea = document.getElementById('hiddenpostareabottom');
		var postform = qform.cloneNode();
		postform.innerHTML = qform.innerHTML;
		postform.onsubmit = function() { set_cookie("scrolldown", "true"); };
		var openform = document.createElement('div');
		openform.className = 'hiddenpostarea';
		openform.id = 'hiddenpostareatop';
		openform.innerHTML = '<br><hr>[ <a onclick="openForm(\'top\'); return false;" class="unhidereplyform" href="#">Раскрыть форму</a> ]<br><hr>';
		var topform = document.getElementsByClassName('postarea')[0];
		if(topform){
			topform.parentNode.insertBefore(openform, topform);
			topform.parentNode.removeChild(topform);
		}
		postarea.className = 'postarea';
		postarea.innerHTML = '';
		if(document.getElementsByClassName('reply quickreply').length > 0) { document.getElementsByClassName('reply quickreply')[0].parentNode.removeChild(document.getElementsByClassName('reply quickreply')[0]); }
		var back = document.createElement('div');
		back.style = 'font-size:0.9em; text-align: left;';
		back.className = 'backdiv';
		back.innerHTML = "[<a href=\"/b/\">Назад</a>]";
		postarea.appendChild(back);
		var threader = document.createElement('div');
		threader.className = 'theader';
		threader.innerHTML = 'Ответ';
		postarea.appendChild(threader);
		postarea.appendChild(postform);
		set_cookie('formopen', 'bottom');
	}
}

function checkForm()
{
	if(get_cookie('formopen') == 'bottom')
	{
		var tform = document.getElementsByClassName('postarea')[0].getElementsByTagName('form')[0];
		var postarea = document.createElement('div');
		document.getElementById('report_form').parentNode.insertBefore(postarea, document.getElementById('report_form'));
		postarea.className = 'postarea';
		var postform = tform.cloneNode();
		postform.innerHTML = tform.innerHTML;
		var openform = document.createElement('div');
		openform.className = 'hiddenpostarea';
		openform.id = 'hiddenpostareatop';
		openform.innerHTML = '<br><hr>[ <a onclick="openForm(\'top\'); return false;" class="unhidereplyform" href="#">Раскрыть форму</a> ]<br><hr>';
		var topform = document.getElementsByClassName('postarea')[0];
		if(topform){
			topform.parentNode.insertBefore(openform, topform);
			topform.parentNode.removeChild(topform);
		}
		var back = document.createElement('div');
		back.style = 'font-size:0.9em; text-align: left;';
		back.innerHTML = "[<a href=\"/b/\">Назад</a>]";
		back.style = 'font-size:0.9em; text-align: left;';
		back.className = 'backdiv';
		postarea.appendChild(back);
		var threader = document.createElement('div');
		threader.className = 'theader';
		threader.innerHTML = 'Ответ';
		postform.onsubmit = function() { set_cookie("scrolldown", "true"); };
		postarea.appendChild(threader);
		postarea.appendChild(postform);
		if(get_cookie('scrolldown').indexOf('true') != -1)
		{
			window.scrollTo(0, document.body.scrollHeight );
			set_cookie('scrolldown', 'false');
		}
	}
	else if(!(window.location.pathname.split('/')[2] == ''))
	{
		var hiddenpostarea = document.createElement('div');
		hiddenpostarea.innerHTML = '<br><hr>[ <a onclick="openForm(\'bottom\'); return false;" class="unhidereplyform" href="#">Раскрыть форму</a> ]<br><hr>';
		document.getElementById('report_form').parentNode.insertBefore(hiddenpostarea, document.getElementById('report_form'));
		hiddenpostarea.className = 'hiddenpostarea';
		hiddenpostarea.id = 'hiddenpostareabottom';
	}
}

function setAdminCheckbox()
{
	var ac = get_cookie('admin');
	if(ac != undefined)
	{
		var sbmtbtn = document.getElementById('submit');
		var checkbox = document.createElement('input');
		checkbox.type = 'checkbox';
		checkbox.name = 'mod_mark';
		checkbox.value = '1';
		checkbox.id = 'mod_mark';
		sbmtbtn.parentNode.insertBefore(checkbox, sbmtbtn.nextSibling);
		var label = document.createElement('label');
		label.htmlFor = 'mod_mark';
		label.innerHTML = '<abbr>Подпись администратора</abbr>';
		checkbox.parentNode.insertBefore(label, checkbox.nextSibling);
	}
}

window.onunload = function(e) {
    if(style_cookie)
    {
        var title = get_active_stylesheet();
        set_cookie(style_cookie,title,365);
    }
};

window.onload = function(e) {
    load_style();
    
    var match;

    if((match=/#i([0-9]+)/.exec(document.location.toString())))
        if(!document.forms.postform.shampoo.value)
            insert(">>"+match[1]);

    if((match=/#([0-9]+)/.exec(document.location.toString())))
        highlight(match[1]);
    lazyadmin();
    $each($X('.//td[@class="reply"]'), function(post) { postByNum[post.id.match(/\d+/)] = post; });
    doRefPreview();
    doRefMap();
	makeQuickReplies();
	checkForm();
	setAdminCheckbox();
	setTimeout(function() {if(document.getElementById('de-main') != undefined) { 
		document.getElementById('updateThread').parentNode.removeChild(document.getElementById('updateThread')); 
		while(document.getElementsByClassName('reply quickreply').length > 0)
		{
			document.getElementsByClassName('reply quickreply')[0].className = 'reply';
		}
	} }, 1000);
};

$(document).keydown(function(e) {
    if (e.which == 116 || e.keyCode == 82 && e.ctrlKey) { //116 = F5
		window.frames[1].reload();
        return false;
    }
});

load_style();
