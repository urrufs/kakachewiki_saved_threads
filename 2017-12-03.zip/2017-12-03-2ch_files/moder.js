var onmenu = false;
function ShowSubMenu(elid)
{
	var menu = document.getElementById(elid + 'submenu');
	menu.style.position = 'absolute';
	menu.style.left = $('#' + elid).offset().left + 'px';
	menu.style.top = $('#' + elid).offset().top * 1.35 + 'px';
	$('#' + elid + 'submenu').show(200);
}
function HideSubMenu(elid)
{
	setTimeout(function() {
		if(!onmenu)
		{
			$('#' + elid + 'submenu').hide(200);
		}
	}, 300);
}
function getMultiplePostsForBanset()
{
	var board = window.location.toString().split('=')[2].replace('#', '');
	var ToAction="";
	var All=document.forms['delform'];
	for (var i=0;i<All.elements.length;++i)
	{
		if(All.elements[i].checked)
		{
			ToAction+="&mod_id_"+ All.elements[i].value+"="+ board+"_"+ All.elements[i].value;
		}
	}
	return ToAction;
}
function addAdminMenu(el, pNum)
{
	var pMultipleNums = getMultiplePostsForBanset();
	var board = window.location.toString().split('=')[2].replace('#', '').replace('&action', '');
	if(pMultipleNums=="")
	{
		pMultipleNums='&mod_id_single='+ board+'_'+ pNum;
	}
	document.body.appendChild($new('div',{'class':'reply','id':'modmenu','style':'left:'+($offset(el,'offsetLeft').toString()- 18)+'px; top:'+
($offset(el,'offsetTop')+ el.offsetHeight- 1).toString()+'px','html':'<a href="/cgi/pihaba?task=moder&action=posts_del'+ pMultipleNums+'" onclick="return areYouShure(this)\">Удалить</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_ban'+ pMultipleNums+'" onclick="return writeBan(this)\">Забанить</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_ban'+ pMultipleNums+'&expires='+ addDate(2)+'" onclick="return writeBan(this)\">Забанить на два дня</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_ban'+ pMultipleNums+'&expires='+ addDate(7)+'" onclick="return writeBan(this)\">Забанить на неделю</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_ban'+ pMultipleNums+'&expires='+ addDate(30)+'" onclick="return writeBan(this)\">Забанить на месяц</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_del_ban'+ pMultipleNums+'" onclick="return writeBan(this)\">Удалить и забанить</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_del_ban'+ pMultipleNums+'&expires='+ addDate(2)+'" onclick="return writeBan(this)\">Удалить и забанить на два дня</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_del_ban'+ pMultipleNums+'&expires='+ addDate(7)+'" onclick="return writeBan(this)\">Удалить и забанить на неделю</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_del_all'+ pMultipleNums+'" onclick="return areYouShure(this)\">Удалить всё</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_del_all_ban'+ pMultipleNums+'" onclick="return writeBan(this)\">Удалить всё и забанить</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_del_all_ban'+ pMultipleNums+'&expires='+ addDate(2)+'" onclick="return writeBan(this)\">Удалить всё и забанить на два дня</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_del_all_in_thread'+ pMultipleNums+'" onclick="return areYouShure(this)\">Удалить всё в треде</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_del_file'+ pMultipleNums+'" onclick="return areYouShure(this)\">Удалить файл</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_mark'+ pMultipleNums+'&mark_type=2" onclick="return areYouShure(this)\">Выдать предупреждение</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_mark'+ pMultipleNums+'&mark_type=1" onclick="return areYouShure(this)\">Метка о бане</a>'
+'<a href="/cgi/pihaba?task=moder&action=thread_stick'+ pMultipleNums+'" onclick="return areYouShure(this)\">Прикрепить тред</a>'
+'<a href="/cgi/pihaba?task=moder&action=thread_unstick'+ pMultipleNums+'" onclick="return areYouShure(this)\">Открепить тред</a>'
+'<a href="/cgi/pihaba?task=moder&action=thread_open'+ pMultipleNums+'" onclick="return areYouShure(this)\">Открыть тред</a>'
+'<a href="/cgi/pihaba?task=moder&action=thread_close'+ pMultipleNums+'" onclick="return areYouShure(this)\">Закрыть тред</a>'
+'<a href="/cgi/pihaba?task=moder&action=thread_move'+ pMultipleNums+'" onclick="return writeBoard(this)\">Перенести тред</a>'
+'<a href="/cgi/pihaba?task=moder&action=post_edit_show'+ pMultipleNums+'" onclick="return areYouShure(this)\">Редактировать пост</a>'
+'<a href="/cgi/pihaba?task=moder&action=add_mod_tag'+ pMultipleNums+'" onclick="return areYouShure(this)\">Добавить мод тег</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_del_everywhere'+ pMultipleNums+'" class="mod-action-massban" onclick="return areYouShure(this)\">Удалить всё на борде</a>'
+'<a href="/cgi/pihaba?task=moder&action=posts_del_everywhere_ban'+ pMultipleNums+'" class="mod-action-massban" onclick="return writeBan(this)\">Удалить все и забанить на борде</a>'}, {'mouseout':removeAdminMenu }));
}

function areYouShure(el)
{
	if(confirm('Вы уверены в своих действиях?'))
	{
		document.location=el.href;
	}
	return false;
}
function writeBan(el)
{
	var reason=prompt('Напишите причину бана, пожалуйста:');if(reason)document.location=el.href+'&comment='+ encodeURIComponent(reason);return false;
}
function writeBoard(el)
{
	var reason=prompt('Укажите доску, куда перенести тред:');if(reason)document.location=el.href+'&new_board='+ encodeURIComponent(reason);return false;
}

function addDate(n)
{
	var d=new Date();
	d.setTime(d.getTime()+ n*24*60*60*1000);
	return d.getFullYear().toString()+'%2F'+(d.getMonth()+ 1).toString()+'%2F'+ d.getDate().toString();
}

function removeAdminMenu(e)
{
	var el = e.relatedTarget;
	while(1)
	{
		if(el.id=='modmenu') break;
		else {el=el.parentNode;if(!el) break; }
	}
	if(!el)$del($id('modmenu'));
}
